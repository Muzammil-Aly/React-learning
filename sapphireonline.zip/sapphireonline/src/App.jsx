import React from 'react'
import Navbar from './Components/Navabar/Navbar'
import DropDown from './Components/Navabar/NavBarDropDown/DropDown';
import HoverLinkComponent from './Components/Navabar/NavBarDropDown/HoverLinkComponent';
import Sliderr from './Components/Navabar/HeroSection/Sliderr';
import DropDownELem from './Components/DropDownELemetns/DropDownELem';


const App = () => {
  return (

    <div>
      <Navbar/>
      <DropDown/>
      <Sliderr/>
      
    </div>
  )
}

export default App
