import React from 'react'
import './Navbar.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope,faMagnifyingGlass,faTruckFast,faUser,faCartShopping} from '@fortawesome/free-solid-svg-icons'
const Navbar = () => {
  return (
    <>

    
    <div class="container">
      <div className="image">
      <a href="#"> 
        <img  src="https://cdn.shopify.com/s/files/1/1592/0041/files/NEW_LOGO_-_Black.svg?v=1675150363"></img>
      </a>

      </div>
<div className="search-box">

    <input class="search-box-input" type="text" placeholder="FIND YOUR FAVOURITES" />


    <div className="search-icon fas fa-home icon-blue ">

    <button >
    <FontAwesomeIcon icon={faMagnifyingGlass} />
    </button>

    </div>
</div>
<div className="right-nav">
    <div className="track-order">
        <a class="fas fa-home fa-2x icon-black" href="#" >
        <FontAwesomeIcon icon={faTruckFast} />
        </a>
    </div>

    <div className="user">
      <a class="fas fa-home fa-2x icon-black " href="#">
      <FontAwesomeIcon  icon={faUser} /> 
      </a>
    </div>
    <div className="cart">
      <a class="fas fa-home fa-2x icon-black" href="#">
      <FontAwesomeIcon icon={faCartShopping} />
      </a>
    </div>
</div>

      
    </div>

<div className="solidline"></div>



</>
)
  
}

export default Navbar
