import React, { useState } from 'react';
import DropDownELem from '../../DropDownELemetns/DropDownELem';

const HoverLinkComponent = () => {
    const [isHovered, setIsHovered] = useState(false);
    const [isDropdownHovered, setIsDropdownHovered] = useState(false);
  
    const handleMouseEnter = () => {
      setIsHovered(true);
    };
  
    const handleMouseLeave = () => {
      if (!isDropdownHovered) {
        setIsHovered(false);
      }
    };
  
    const handleDropdownMouseEnter = () => {
      setIsDropdownHovered(true);
    };
  
    const handleDropdownMouseLeave = () => {
      setIsDropdownHovered(false);
      if (!isHovered) {
        setIsHovered(false);
      }
    };

  return (
    <div
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{ position: 'relative', display: 'inline-block' }}
    >
      <a
      >
        NEW IN
      </a>

      {isHovered && (
        <div
        onMouseEnter={handleDropdownMouseEnter}
        onMouseLeave={handleDropdownMouseLeave}
        style={{
            position: 'absolute',
            top:300,
            left: 0,
            backgroundColor: 'black',
            right: 0,
            bottom:0, 
            color: 'white',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            pointerEvents: 'auto',
            zIndex: 1000, // Ensures it appears on top
            
          
        }}
         
        >
         <DropDownELem/>
        </div>
      )}
    </div>
  );
};

export default HoverLinkComponent;
