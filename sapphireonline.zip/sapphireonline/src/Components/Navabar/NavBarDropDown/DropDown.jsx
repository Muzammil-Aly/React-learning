import React from 'react'
import './DropDown.css'
import HoverLinkComponent from './HoverLinkComponent'

const DropDown = () => {
   

    return (
   <>
   <div className="list-items">

<li> 
  <a href="#">
  <HoverLinkComponent/>
  </a> 
     
  

  </li>
  
  

<li>
  <a href="#">
  <a href="#">
  <HoverLinkComponent/>
  </a> 
    </a></li>
<li>
<a href="#">
MAN
    </a></li>
<li>
<a href="#">
KIDS
    </a></li>
<li>
<a href="#">
BEAUTY
    </a></li>
<li>
<a href="#">
ACCESSORIES
    </a></li>
<li>
<a href="#">
HOME
    </a></li>
<li>
<a href="#">
SPECAIL OFFERS
    </a></li>
<li>
<a href="#">
THE EDIT
    </a>
    </li>
</div>
   
   </>
  )
}

export default DropDown
